from .sprite import Figur
from .stage import Bühne

sprite_class = Figur
stage_class = Bühne

__all__ = ["Figur", "Bühne"]
